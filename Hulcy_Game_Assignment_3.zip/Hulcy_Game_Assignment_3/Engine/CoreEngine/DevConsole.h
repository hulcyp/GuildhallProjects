#pragma once
#include "Colors.h"

namespace pdh
{
	void consolePrintf( const char* text, Color4f color, ... ); 
}