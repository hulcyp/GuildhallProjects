/** Automatically generated file. DO NOT MODIFY */
package c19.hulcy.rpsls;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}