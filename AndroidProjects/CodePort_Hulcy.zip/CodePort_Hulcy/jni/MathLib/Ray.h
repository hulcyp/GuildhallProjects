#pragma once


namespace Monky
{
	template< typename T >
	class Ray
	{
	
	};
}