/** Automatically generated file. DO NOT MODIFY */
package com.c19.codeport.hulcy;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}