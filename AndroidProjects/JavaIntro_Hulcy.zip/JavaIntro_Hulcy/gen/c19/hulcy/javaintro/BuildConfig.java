/** Automatically generated file. DO NOT MODIFY */
package c19.hulcy.javaintro;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}