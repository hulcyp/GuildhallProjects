/** Automatically generated file. DO NOT MODIFY */
package c19.hulcy.glprimitivesdemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}