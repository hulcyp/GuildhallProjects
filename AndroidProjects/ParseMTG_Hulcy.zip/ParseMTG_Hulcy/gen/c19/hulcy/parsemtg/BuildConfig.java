/** Automatically generated file. DO NOT MODIFY */
package c19.hulcy.parsemtg;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}